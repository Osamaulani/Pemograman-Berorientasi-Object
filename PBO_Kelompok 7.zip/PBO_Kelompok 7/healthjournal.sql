-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 06, 2024 at 02:43 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthjournal`
--

-- --------------------------------------------------------

--
-- Table structure for table `meal`
--

CREATE TABLE `meal` (
  `meal_id` varchar(50) NOT NULL,
  `meal_name` varchar(255) NOT NULL,
  `ingredients` varchar(255) NOT NULL,
  `tools` varchar(255) NOT NULL,
  `steps` varchar(255) NOT NULL,
  `calories` int(11) NOT NULL,
  `proteins` int(11) NOT NULL,
  `carbohydrates` int(11) NOT NULL,
  `fats` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meal`
--

INSERT INTO `meal` (`meal_id`, `meal_name`, `ingredients`, `tools`, `steps`, `calories`, `proteins`, `carbohydrates`, `fats`, `user_id`) VALUES
('meal102', 'ayam goreng ', 'ayam , bumbu rempah, nasi goreng', 'wajan, pisau ', 'Setelah air mendidih, kecilkan api ke api sedang. Bolak-baik ayam menggunakan capiran agar kulit tidak mudah sobek. Tutup panci sambil beberapa kali diaduk. Masak selama 15-20menit.\r\n\r\nBesarkan api agar air mudah menyusut. Pada tahap ini sebaiknya ayam ti', 400, 20, 100, 30, 0),
('meal103', 'mie goreng', 'mie, bumbu rempah, minyak goreng', 'wajan, pisau', 'hdsuhfuhdsfsdhovfsovb fi b', 20, 300, 120, 400, 0),
('meal104', 'jdkjskcds', 'eudhxfdhcfidf', 'dhiehdsdnjdjf', 'djkjdnnkhds', 30, 40, 60, 7, 0);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `schedule_id` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `meal_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `age` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `weight` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `username`, `email`, `password`, `gender`, `age`, `height`, `weight`) VALUES
('user001', 'egi dhea n', 'egidhea', 'egidhea18@gmail.com', '18092003', 'Female', 20, 167, 54),
('user002', 'osa', 'osanas', 'osanas20@gmai.com', '202025osa', 'Female', 20, 154, 60),
('user003', 'mauulll', 'maulana', '', '12345', 'Male', 20, 170, 55),
('user004', 'luhungg', 'luhungefde', 'luhung@gmial.com', '12345', 'Male', 21, 175, 50);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `meal`
--
ALTER TABLE `meal`
  ADD PRIMARY KEY (`meal_id`) USING BTREE;

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`schedule_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
